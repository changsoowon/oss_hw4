document.addEventListener('DOMContentLoaded', function() {
    const canvas = document.getElementById('radarCanvas');
    const ctx = canvas.getContext('2d');

    // Set canvas dimensions for high DPI screens
    const devicePixelRatio = window.devicePixelRatio || 1;
    const size = 700;
    canvas.width = size * devicePixelRatio;
    canvas.height = size * devicePixelRatio;
    canvas.style.width = `${size}px`;
    canvas.style.height = `${size}px`;
    ctx.scale(devicePixelRatio, devicePixelRatio);

    const maxValue = 100;
    const labels = ['Happiness', 'Intelligence', 'Luck', 'Stamina', 'Sociability'];
    const data = [70, 80, 65, 70, 50];
    const angleStep = (2 * Math.PI) / labels.length;

    function drawRadarChart(progress) {
        ctx.clearRect(0, 0, canvas.width / devicePixelRatio, canvas.height / devicePixelRatio);

        ctx.beginPath();
        ctx.moveTo(
            size / 2 + (data[0] / maxValue * size / 2 * progress) * Math.cos(0),
            size / 2 - (data[0] / maxValue * size / 2 * progress) * Math.sin(0)
        );

        for (let i = 1; i < labels.length; i++) {
            ctx.lineTo(
                size / 2 + (data[i] / maxValue * size / 2 * progress) * Math.cos(i * angleStep),
                size / 2 - (data[i] / maxValue * size / 2 * progress) * Math.sin(i * angleStep)
            );
        }

        ctx.closePath();
        ctx.strokeStyle = 'rgba(255, 175, 208, 0.8)';
        ctx.fillStyle = 'rgba(255, 175, 208, 0.2)';
        ctx.fill();
        ctx.stroke();

        // 항목 이름 
        for (let i = 0; i < labels.length; i++) {
            const x = size / 2 + (data[i] / maxValue * size / 2 * progress) * Math.cos(i * angleStep);
            const y = size / 2 - (data[i] / maxValue * size / 2 * progress) * Math.sin(i * angleStep);

            ctx.fillStyle = 'rgba(252, 199, 221, 0.982)';
            ctx.font = '16px Arial';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(labels[i], x, y);
        }
    }

    let progress = 0;
    const animationDuration = 5000; 
    const frameRate = 40; 
    const totalFrames = (animationDuration / 1000) * frameRate;

    function animate() {
        progress += 1 / totalFrames;
        drawRadarChart(progress);

        if (progress < 1) {
            requestAnimationFrame(animate);
        }
    }

    animate();
});

